# Sbt Puppet Module for Boxen

Requires the following boxen modules:

## Usage

```puppet
include sbt
```

## Required Puppet Modules

* boxen
* homebrew

